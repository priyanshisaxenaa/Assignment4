\# Software Lab - Version Control Assignments

\*\*Student:\*\* Priyanshi Saxena  

\*\*Roll Number / ID:\*\* 26m0744  



This repository contains the projects and version control workflows completed for the Software Lab assignments using Git and Bash.



\---



\## Part 1: HTML Website Version Control (Assignment 1)



This section covers the creation and version management of a personal HTML homepage.



\### Project Details \& Features

\* \*\*`index.html`\*\*: Personal homepage containing:

&#x20; \* Bio and M.Tech student status at IIT Bombay\[cite: 1].

&#x20; \* Educational background (B.Tech CSAI from AKTU, GATE 2026 AIR 11)\[cite: 1].

&#x20; \* Professional experience (SDE at TestMu AI / Kane AI chatbot)\[cite: 1].

&#x20; \* Personal interests and contact links\[cite: 1].

\* \*\*Branches Used\*\*:

&#x20; \* `master` (or `main`): Primary branch containing base layout and warm tan/brown color themes.

&#x20; \* `alternative-version`: Branch featuring an alternative dark theme layout.



\### Git Workflow Commands

```bash

\# Initialize repository and configure user details

git init

git config --global user.name "Priyanshi Saxena"

git config --global user.email "26m0744@iitb.ac.in"



\# Initial commit of the website

git add index.html

git commit -m "Initial commit: Add base homepage for Priyanshi Saxena"



\# Modify background and commit updates

sed -i 's/#cdaa92/#d2b48c/g' index.html

git add index.html

git commit -m "Update background color to a warmer tan shade"



\# Create alternative branch for styling changes

git checkout -b alternative-version

sed -i 's/#d2b48c/#2b2b2b/g' index.html

git add index.html

git commit -m "Change to dark theme layout on alternative branch"



## **Commit History Graph**



\* 4fced9e (HEAD -> alternative-version) Change to dark theme layout on alternative branch

\* f541ce8 (master) Update background color to a warmer tan shade

\* 9b404e7 Initial commit: Add base homepage for Priyanshi Saxena


**ques2**





\# Create project folder and initial data files

mkdir lecture1-project

cd lecture1-project

git init



\# Add data and notes files

git add data.csv notes.txt

git commit -m "Initial commit: Add Lecture 1 data and notes files"



\# Create a feature branch for parallel development

git checkout -b feature-branch

mkdir analysis

\# (Add analysis script and update notes, then commit)

git add analysis/summary.py notes.txt

git commit -m "Add analysis folder and update notes on feature-branch"



\# Switch back to master and make concurrent changes to notes.txt

git checkout master

\# (Edit notes.txt with master updates)

git add notes.txt

git commit -m "Update notes.txt differently on master branch"



\# Merge branches (handles merge conflict resolution on notes.txt)

git merge feature-branch

Commit History Graph



\*   5a8ab80 (HEAD -> master) Merge branch 'feature-branch'

|\\

| \* bb6a738 (feature-branch) Update notes.txt differently on master branch

| \* 1f637df Add analysis folder and update notes on feature-branch

\* | c524698 Update notes.txt differently on master branch

|/

\* 5df2f99 Update notes.txt with additional details from lecture

\* 653f23e Initial commit: Add Lecture 1 data and notes files

